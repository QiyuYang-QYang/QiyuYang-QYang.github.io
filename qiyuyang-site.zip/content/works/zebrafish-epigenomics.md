---
title: Zebrafish epigenomics
year: "2025"
tags: ATAC · ChIP · MethylC-seq
where: Lee Lab, University of Pittsburgh
order: 4
---
Enhancer pipelines and methylation analysis across early zebrafish development.
