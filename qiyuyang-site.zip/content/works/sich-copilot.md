---
title: sICH-Copilot
year: "2026"
tags: LLM agent · clinical prediction
where: SRIBD
order: 1
---
An agent that predicts outcomes for sICH patients by combining a classical model, case retrieval and a knowledge graph, then writing a report that shows its evidence. Includes a tool-divergence diagnostic for when the tools disagree.
