---
title: OncoLearn
year: "2026"
tags: Federated learning · TCGA-BRCA
where: NVIDIA Bio Hackathon
order: 2
---
Breast cancer molecular subtyping trained across sites without pooling patient data in one place.
