---
title: Elastic-net gene selection
year: "2025"
tags: Statistical learning · genomics
where: Personal research
order: 3
---
Subtype-specific gene panels from a hand-rolled elastic net, now being generalized into a reusable framework.
