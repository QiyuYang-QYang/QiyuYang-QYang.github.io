---
title: Sample essay
date: 2026-10-18
summary: A placeholder showing how an essay looks. Replace or delete it in the editor.
draft: false
---
This is a sample essay. Write in the editor's rich-text box and it appears here, set in the site's type.

## A section heading

Paragraphs, **bold**, *italic*, links, lists and quotes all carry over.

> A quotation sits apart from the text like this.

- First point
- Second point
